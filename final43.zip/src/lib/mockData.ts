// Types
export interface Track {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
}

// Mock Data
export const mockTracks: Track[] = [
  {
    id: 1,
    title: "AI & Machine Learning",
    description: "Build the next generation of intelligent systems. Focus on LLMs, Computer Vision, and Predictive Analytics.",
    imageUrl: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2565&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "Blockchain & Web3",
    description: "Decentralize the future. Create dApps, Smart Contracts, and new financial paradigms.",
    imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=2832&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "Future of FinTech",
    description: "Revolutionize how we exchange value. Payments, Banking, and Personal Finance re-imagined.",
    imageUrl: "https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=2670&auto=format&fit=crop"
  },
  {
    id: 4,
    title: "Sustainability",
    description: "Tech for a greener planet. Renewable energy, waste reduction, and eco-friendly solutions.",
    imageUrl: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2670&auto=format&fit=crop"
  },
  {
    id: 5,
    title: "HealthTech Innovation",
    description: "Transform healthcare with cutting-edge technology. Telemedicine, diagnostics, and patient care solutions.",
    imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=2670&auto=format&fit=crop"
  },
  {
    id: 6,
    title: "EdTech Revolution",
    description: "Reimagine education for the digital age. Interactive learning platforms and personalized education tools.",
    imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=2622&auto=format&fit=crop"
  }
];
